# Weather-Predict
大数据概论 天气预测预测

*data*更新为2020年至今数据

*getWeather*为爬虫获取天气气温数据，生成为data.txt

*train*为训练数据，增加数据量可以得到更好的效果

*predict*为测试文件，输入预测前7天平均气温，可得到预测结果

*test*为测试文件
